# SENTINEL Boundary

SENTINEL is a governance and safety boundary, not an autonomous authority.

## Required controls

1. Validate the actor and requested capability.
2. Validate scope and permissions.
3. Treat external content and model outputs as untrusted input.
4. Detect attempts to bypass policy or authorization.
5. Require human review for consequential or ambiguous actions.
6. Log material decisions without storing unnecessary sensitive data.
7. Fail closed when authorization cannot be established.

SENTINEL must never silently convert a recommendation into an action.

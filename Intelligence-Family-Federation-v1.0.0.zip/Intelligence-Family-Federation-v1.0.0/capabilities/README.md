# Capabilities

Capabilities describe what a system can contribute without binding the Family architecture to a particular provider.

Examples: coding, reasoning, research, creative work, and data processing.

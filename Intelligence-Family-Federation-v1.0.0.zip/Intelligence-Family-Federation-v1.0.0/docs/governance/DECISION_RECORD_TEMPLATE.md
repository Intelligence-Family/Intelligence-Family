# Architecture Decision Record

- **ID:** ADR-XXXX
- **Date:** YYYY-MM-DD
- **Status:** Proposed | Accepted | Rejected | Superseded
- **Decision owner:** Human maintainer

## Context

What problem are we solving?

## Decision

What are we choosing?

## Alternatives considered

1.
2.
3.

## Safety / privacy / security impact

- Least privilege:
- Human approval:
- Data exposure:
- Failure boundary:

## Provenance / licensing

Identify external sources and applicable terms.

## Reversibility

How can the decision be rolled back?

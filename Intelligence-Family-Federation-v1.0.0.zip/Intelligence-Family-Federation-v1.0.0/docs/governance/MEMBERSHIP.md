# Family Membership & Provenance

## Purpose

Membership records collaboration, not ownership, endorsement, employment, or affiliation.

## Required record

Every Family member entry should identify:

- public name;
- provider/organization, where applicable;
- Family role;
- capabilities represented;
- contribution history;
- source/provenance;
- applicable license or usage terms for contributed artifacts;
- integration status (candidate, reviewed, approved, retired).

## Independence

A provider remains independent. Family membership never grants access to another provider's systems, credentials, repositories, or data.

## Human authority

Human authorization remains the highest project-level authority. No agent may expand its own permissions, appoint itself to a privileged role, or bypass a required approval gate.

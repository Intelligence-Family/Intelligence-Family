# Skills

Skills are reusable instructions, procedures, or capability definitions. Each skill should state its purpose, triggers, inputs, outputs, safety constraints, provenance, and tests where practical.

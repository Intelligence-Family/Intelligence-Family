# Provider Adapters

Provider integrations belong here. Keep provider-specific authentication, request formats, limits, and failure handling isolated from the Family core.

Never commit credentials. Prefer environment variables or an approved secret manager in deployment environments.

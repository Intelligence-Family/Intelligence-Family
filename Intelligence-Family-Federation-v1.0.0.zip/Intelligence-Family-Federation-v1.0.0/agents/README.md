# Agent Layer

Agents are tools that can execute work. They are not separate Family identities merely because they use a particular model.

Examples include coding agents, terminal agents, IDE agents, workflow agents, and CI automation.

Every agent integration must document:

- identity/provider;
- capabilities;
- required permissions;
- allowed actions;
- prohibited actions;
- approval requirements;
- audit/rollback behavior.

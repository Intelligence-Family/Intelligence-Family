# Contribution Checklist

Before accepting a Family contribution:

- [ ] Human maintainer identified and authorized the change.
- [ ] Source/provenance recorded.
- [ ] License/usage terms checked.
- [ ] No secrets or credentials included.
- [ ] Dependencies identified.
- [ ] External code reviewed before integration.
- [ ] Prompt-injection / untrusted-input surfaces considered.
- [ ] Permissions follow least privilege.
- [ ] Consequential actions have an appropriate approval gate.
- [ ] Tests/validation added or run where applicable.
- [ ] Documentation updated.
- [ ] Rollback path identified.

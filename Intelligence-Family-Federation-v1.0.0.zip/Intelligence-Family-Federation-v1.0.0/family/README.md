# Family Member Records

Each directory under `family/` represents a Family member/provider relationship and should contain provenance and capability documentation.

Do not place proprietary model weights, credentials, private datasets, or external repositories here unless separately reviewed and legally appropriate.
